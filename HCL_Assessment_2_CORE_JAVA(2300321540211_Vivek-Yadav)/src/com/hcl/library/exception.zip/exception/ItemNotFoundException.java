package com.hcl.library.exception;

public class ItemNotFoundException extends LibraryException {
    public ItemNotFoundException(String message) {
        super(message);
    }

    public ItemNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
